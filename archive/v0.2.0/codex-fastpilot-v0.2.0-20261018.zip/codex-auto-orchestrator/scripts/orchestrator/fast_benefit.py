from __future__ import annotations

import hashlib
import json
import math
import os
import statistics
import time
import tomllib
from pathlib import Path
from typing import Any

from .util import atomic_write_json, exclusive_file_lock, load_json


MIN_SAMPLES = 5
MAX_AGE_SECONDS = 7 * 24 * 60 * 60
MAX_RECORDS = 1000
MIN_USEFUL_GAIN = 1.10


def _volume_bucket(tokens: int) -> str:
    width = tokens.bit_length()
    return f"{width}:{tokens // (1 << max(0, width - 3))}"


def runtime_scope(command: list[str], chatgpt_login: bool) -> str:
    """Separate providers, credentials and config generations without storing secrets."""
    home = Path(os.environ.get("CODEX_HOME") or Path.home() / ".codex").resolve()
    parts: list[Any] = [command, str(home), chatgpt_login]
    config: dict[str, Any] = {}
    for name in ("config.toml", "auth.json"):
        path = home / name
        try:
            stat = path.stat()
            parts.append([name, stat.st_size, stat.st_mtime_ns])
        except OSError:
            parts.append([name, None])
    try:
        config = tomllib.loads((home / "config.toml").read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        pass
    provider = config.get("model_provider", "openai")
    providers = config.get("model_providers", {})
    info = providers.get(provider, {}) if isinstance(providers, dict) and isinstance(provider, str) else {}
    if not isinstance(info, dict):
        info = {}
    parts.append([provider, info.get("base_url"), info.get("wire_api")])
    names = {"OPENAI_API_KEY", "CODEX_API_KEY"}
    if isinstance(info.get("env_key"), str):
        names.add(info["env_key"])
    for name in sorted(names):
        value = os.environ.get(name, "")
        parts.append([name, hashlib.sha256(value.encode()).hexdigest()])
    return hashlib.sha256(json.dumps(parts, sort_keys=True).encode()).hexdigest()


def comparison_group(scope: str, model: str, effort: str, key: str, prompt: str, schema: Path) -> str:
    role = (
        "planner" if key.startswith("planner-") else
        "reviewer" if key.startswith("final-review-") else
        "worker" if key.startswith("worker-") else "other"
    )
    identity = [scope, model, effort, role, len(prompt.encode("utf-8")).bit_length()]
    identity.append(hashlib.sha256(schema.read_bytes()).hexdigest())
    return hashlib.sha256(json.dumps(identity).encode()).hexdigest()


class InferenceTiming:
    """Only tool-free, single-turn traces have an unambiguous elapsed-time sample."""
    def __init__(self) -> None:
        self.started: float | None = None
        self.starts = 0
        self.completions = 0
        self.has_tools = False
        self.sample: dict[str, Any] | None = None

    def observe(self, line: str, now: float) -> None:
        try:
            event = json.loads(line)
        except (ValueError, TypeError):
            return
        if not isinstance(event, dict):
            return
        kind = event.get("type")
        if kind == "turn.started":
            self.started = now
            self.starts += 1
        item = event.get("item")
        if kind in {"item.started", "item.completed", "item.updated"} and isinstance(item, dict):
            if item.get("type") not in {"agent_message", "reasoning"}:
                self.has_tools = True
        if kind != "turn.completed":
            return
        self.completions += 1
        usage = event.get("usage", {})
        if not isinstance(usage, dict):
            return
        incoming, outgoing = usage.get("input_tokens"), usage.get("output_tokens")
        cached = usage.get("cached_input_tokens")
        if cached is None and isinstance(usage.get("input_tokens_details"), dict):
            cached = usage["input_tokens_details"].get("cached_tokens")
        tier = event.get("service_tier")
        if (
            self.started is None or self.starts != 1 or self.has_tools
            or not all(type(n) is int for n in (incoming, outgoing, cached))
            or incoming <= 0 or outgoing < 32 or cached < 0 or cached > incoming
            or now - self.started < 0.5
            or tier not in {"default", "priority", "fast"}
        ):
            return
        self.sample = {
            "tier": "priority" if tier == "fast" else tier,
            "elapsed_seconds": now - self.started,
            "input_tokens": incoming,
            "output_tokens": outgoing,
            "cached_input_tokens": cached,
        }

    def result(self) -> dict[str, Any] | None:
        if self.starts != 1 or self.completions != 1 or self.has_tools:
            return None
        return self.sample


class FastBenefitHistory:
    def __init__(self, path: Path, *, clock=time.time) -> None:
        self.path = path
        self.lock_path = path.with_suffix(".lock")
        self.clock = clock

    def _read(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        value = load_json(self.path)
        if not isinstance(value, dict) or value.get("version") != 1 or not isinstance(value.get("samples"), list):
            raise ValueError("invalid Fast benefit history")
        now = self.clock()
        valid = []
        for sample in value["samples"]:
            if not isinstance(sample, dict):
                continue
            required = ("id", "group", "bucket", "tier", "at", "rate")
            if not all(k in sample for k in required):
                continue
            if (
                not all(isinstance(sample[k], str) for k in ("id", "group", "bucket", "tier"))
                or
                sample["tier"] not in {"default", "priority"}
                or not isinstance(sample["rate"], (int, float))
                or not math.isfinite(sample["rate"]) or sample["rate"] <= 0
                or not isinstance(sample["at"], (int, float))
                or not math.isfinite(sample["at"])
                or not 0 <= now - sample["at"] <= MAX_AGE_SECONDS
            ):
                continue
            valid.append(sample)
        return valid[-MAX_RECORDS:]

    def record(self, group: str, identity: str, metric: dict[str, Any]) -> None:
        incoming, outgoing = metric["input_tokens"], metric["output_tokens"]
        cached = metric["cached_input_tokens"]
        cache = "cold" if cached == 0 else "warm" if cached / incoming >= 0.5 else "partial"
        sample = {
            "id": hashlib.sha256(identity.encode()).hexdigest(),
            "group": group,
            "bucket": f"{_volume_bucket(incoming)}:{_volume_bucket(outgoing)}:{cache}",
            "tier": metric["tier"],
            "rate": outgoing / metric["elapsed_seconds"],
            "at": self.clock(),
        }
        with exclusive_file_lock(self.lock_path):
            samples = self._read()
            if any(s["id"] == sample["id"] for s in samples):
                return
            samples.append(sample)
            atomic_write_json(self.path, {"version": 1, "samples": samples[-MAX_RECORDS:]})

    def choose(self, group: str) -> dict[str, Any]:
        with exclusive_file_lock(self.lock_path):
            records = [sample for sample in self._read() if sample["group"] == group]
        buckets: dict[str, dict[str, list[float]]] = {}
        for sample in records:
            bucket = buckets.setdefault(sample["bucket"], {"default": [], "priority": []})
            bucket[sample["tier"]].append(sample["rate"])
        comparisons = []
        for rates in buckets.values():
            standard, fast = rates["default"], rates["priority"]
            if min(len(standard), len(fast)) < MIN_SAMPLES:
                return {"downgrade": False, "reason": "insufficient_comparable_samples"}
            standard.sort()
            fast.sort()
            lower_standard = standard[(len(standard) - 1) // 4]
            upper_fast = fast[3 * (len(fast) - 1) // 4]
            comparisons.append({
                "standard_samples": len(standard), "fast_samples": len(fast),
                "median_gain": statistics.median(fast) / statistics.median(standard),
                "low_gain": upper_fast <= lower_standard * MIN_USEFUL_GAIN,
            })
        if not comparisons:
            return {"downgrade": False, "reason": "insufficient_comparable_samples"}
        downgrade = all(item["low_gain"] for item in comparisons)
        return {
            "downgrade": downgrade,
            "reason": "observed_fast_gain_below_threshold" if downgrade else "keep_profile_fast",
            "minimum_useful_gain": MIN_USEFUL_GAIN,
            "comparisons": comparisons,
        }
