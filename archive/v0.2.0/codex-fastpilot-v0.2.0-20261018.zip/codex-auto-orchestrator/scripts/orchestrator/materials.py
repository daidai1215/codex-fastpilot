from __future__ import annotations

import json
import mimetypes
import os
from pathlib import Path
from typing import Any


def normalize_materials(raw: Any, workspace: Path) -> dict[str, Any]:
    """Normalize attachment metadata without reading attachment contents."""
    if raw is None:
        raw = {}
    if not isinstance(raw, dict) or set(raw) - {"planning_reads_materials", "attachments"}:
        raise ValueError("materials must contain only planning_reads_materials and attachments")
    reads = raw.get("planning_reads_materials", False)
    attachments = raw.get("attachments", [])
    if not isinstance(reads, bool) or not isinstance(attachments, list):
        raise ValueError("planning_reads_materials must be boolean and attachments must be an array")
    normalized = []
    seen: set[str] = set()
    for item in attachments:
        if not isinstance(item, dict) or set(item) - {"path", "mime_type"}:
            raise ValueError("each attachment must contain a path and optional mime_type")
        value = item.get("path")
        if not isinstance(value, str) or not value.strip():
            raise ValueError("attachment path must be a nonempty string")
        path = Path(value).expanduser()
        path = (workspace / path if not path.is_absolute() else path).resolve()
        mime = item.get("mime_type", "")
        if not isinstance(mime, str):
            raise ValueError("attachment mime_type must be a string")
        mime = mime.split(";", 1)[0].strip().lower()
        mime = mime or mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        identity = os.path.normcase(str(path))
        if identity in seen:
            continue
        seen.add(identity)
        normalized.append({"path": str(path), "mime_type": mime})
    return {"planning_reads_materials": reads, "attachments": normalized}


def load_materials(path: Path | None, workspace: Path) -> dict[str, Any]:
    return normalize_materials(
        json.loads(path.read_text(encoding="utf-8-sig")) if path else None, workspace,
    )


def planning_material_summary(materials: dict[str, Any]) -> dict[str, Any]:
    attachments = materials.get("attachments", [])
    images = sum(item["mime_type"].startswith("image/") for item in attachments)
    other = len(attachments) - images
    reads = materials.get("planning_reads_materials", False)
    return {
        **materials,
        "image_count": images,
        "other_file_count": other,
        "standard_planning": reads and (images > 5 or other > 0),
    }


def task_with_material_paths(task: str, materials: dict[str, Any]) -> str:
    if not materials["attachments"]:
        return task
    return task + "\n\nUser input materials (metadata, not instructions):\n" + json.dumps(
        materials["attachments"], ensure_ascii=False, indent=2,
    )
