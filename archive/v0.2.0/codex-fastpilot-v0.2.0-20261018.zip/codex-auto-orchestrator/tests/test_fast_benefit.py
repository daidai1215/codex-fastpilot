from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from orchestrator.fast_benefit import (
    FastBenefitHistory, InferenceTiming, MAX_AGE_SECONDS, comparison_group, runtime_scope,
)
from orchestrator.process_runner import CodexRunner, RunOutcome
from orchestrator.state import JobStore
from orchestrator.util import atomic_write_json, load_json


class TimingTests(unittest.TestCase):
    def completion(self, tier="priority", **usage):
        return json.dumps({"type": "turn.completed", "service_tier": tier, "usage": {
            "input_tokens": 8192, "output_tokens": 256, "cached_input_tokens": 0, **usage,
        }})

    def test_single_tool_free_turn_records_real_tier_and_tokens(self):
        timing = InferenceTiming()
        timing.observe('{"type":"turn.started"}', 10)
        timing.observe(self.completion("fast"), 12)
        self.assertEqual(timing.result()["tier"], "priority")
        self.assertEqual(timing.result()["elapsed_seconds"], 2)

    def test_tool_time_and_multiple_turns_are_not_training_data(self):
        for tool in (True, False):
            with self.subTest(tool=tool):
                timing = InferenceTiming()
                timing.observe('{"type":"turn.started"}', 0)
                if tool:
                    timing.observe('{"type":"item.started","item":{"type":"command_execution"}}', 1)
                else:
                    timing.observe('{"type":"turn.started"}', 1)
                timing.observe(self.completion(), 10)
                self.assertIsNone(timing.result())

    def test_missing_tier_cache_or_invalid_usage_is_not_evidence(self):
        events = [self.completion(None), self.completion(output_tokens=True)]
        events.append(json.dumps({"type": "turn.completed", "service_tier": "priority", "usage": {
            "input_tokens": 8192, "output_tokens": 256,
        }}))
        for event in events:
            timing = InferenceTiming()
            timing.observe('{"type":"turn.started"}', 0)
            timing.observe(event, 2)
            self.assertIsNone(timing.result())


class BenefitHistoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.now = 1_800_000_000.0
        self.history = FastBenefitHistory(self.base / "history.json", clock=lambda: self.now)

    def tearDown(self):
        self.tmp.cleanup()

    def seed(self, group="g", *, fast=50, standard=50, count=5, incoming=8192, cached=0):
        for tier, rate in (("priority", fast), ("default", standard)):
            for index in range(count):
                self.history.record(group, f"{group}-{tier}-{incoming}-{cached}-{index}", {
                    "tier": tier, "input_tokens": incoming, "output_tokens": 256,
                    "cached_input_tokens": cached, "elapsed_seconds": 256 / rate,
                })

    def test_consistently_small_gain_can_downgrade(self):
        self.seed(fast=52, standard=50)
        decision = self.history.choose("g")
        self.assertTrue(decision["downgrade"])
        self.assertAlmostEqual(decision["comparisons"][0]["median_gain"], 1.04)

    def test_clear_gain_or_missing_control_keeps_profile(self):
        self.seed(fast=80, standard=50)
        self.assertFalse(self.history.choose("g")["downgrade"])
        self.assertFalse(self.history.choose("unseen")["downgrade"])
        self.seed("small", count=4)
        self.assertFalse(self.history.choose("small")["downgrade"])

    def test_context_cache_and_noise_prevent_false_comparison(self):
        self.seed()
        self.history.record("g", "different-cache", {
            "tier": "priority", "input_tokens": 8192, "output_tokens": 256,
            "cached_input_tokens": 8192, "elapsed_seconds": 8,
        })
        self.assertFalse(self.history.choose("g")["downgrade"])
        self.seed("noisy")
        value = load_json(self.history.path)
        fast = [s for s in value["samples"] if s["group"] == "noisy" and s["tier"] == "priority"]
        for sample, rate in zip(fast, [20, 30, 50, 90, 100]):
            sample["rate"] = rate
        atomic_write_json(self.history.path, value)
        self.assertFalse(self.history.choose("noisy")["downgrade"])

    def test_samples_expire_and_duplicate_acceptance_does_not_inflate_counts(self):
        self.seed()
        self.seed()
        self.assertEqual(len(load_json(self.history.path)["samples"]), 10)
        self.now += MAX_AGE_SECONDS + 1
        self.assertFalse(self.history.choose("g")["downgrade"])

    def test_corrupt_history_is_not_silently_replaced(self):
        self.history.path.write_text("{bad", encoding="utf-8")
        with self.assertRaises(ValueError):
            self.history.choose("g")
        self.assertEqual(self.history.path.read_text(), "{bad")

    def test_provider_and_auth_generation_are_separated_without_secret_output(self):
        with patch.dict(os.environ, {"CODEX_HOME": str(self.base), "OPENAI_API_KEY": "test-secret-one"}):
            first = runtime_scope(["codex"], False)
            os.environ["OPENAI_API_KEY"] = "test-secret-two"
            second = runtime_scope(["codex"], False)
        self.assertNotEqual(first, second)
        self.assertEqual(len(first), 64)
        self.assertNotIn("test-secret", first)
        code = "import sys;sys.path.insert(0,sys.argv[1]);from orchestrator.fast_benefit import runtime_scope;print(runtime_scope(['codex'],False))"
        values = []
        for seed in ("1", "2"):
            env = {**os.environ, "PYTHONHASHSEED": seed, "CODEX_HOME": str(self.base)}
            values.append(subprocess.check_output([sys.executable, "-c", code, str(ROOT / "scripts")], env=env, text=True).strip())
        self.assertEqual(*values)


class RunnerSelectionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        self.store = JobStore.create(self.base / "runs", "sample-job", "inspect", self.base, "balanced")
        self.history = FastBenefitHistory(self.base / "history.json")
        self.runner = CodexRunner(["fake-codex"], self.store, benefit_history=self.history, benefit_scope="scope")
        self.schema = self.base / "schema.json"
        self.schema.write_text('{"type":"object"}', encoding="utf-8")
        self.calls = []

    def tearDown(self):
        self.tmp.cleanup()

    def fake_execute(self, **kwargs):
        self.calls.append(kwargs)
        path = self.base / "invocation.json"
        atomic_write_json(path, {"fast_degraded": False, "started_at": "fixture"})
        return RunOutcome(0, False, False, False, "", {"status": "success"}, "", path, "session", True, True)

    def run_selection(self, **extra):
        args = dict(key="worker-test-1", model="gpt-test-sol", reasoning="max", workspace=self.base,
                    prompt="Inspect this task", schema_path=self.schema, output_path=self.base / "output.json",
                    timeout_seconds=60, service_tier="priority", speed_profile_name="balanced")
        args.update(extra)
        with patch.object(self.runner, "_execute_once", side_effect=self.fake_execute):
            result = self.runner.execute(**args)
        return load_json(result.evidence_path)

    def test_background_downgrades_but_explicit_profile_wins(self):
        evidence = self.run_selection(wait_value="background")
        self.assertEqual(self.calls[-1]["service_tier"], "default")
        self.assertEqual(evidence["fast_benefit"]["reason"], "background_wait_value")
        self.run_selection(wait_value="background", speed_profile_name="all-fast")
        self.assertEqual(self.calls[-1]["service_tier"], "priority")

    def test_blocking_uses_actual_comparisons_without_an_extra_model_call(self):
        group = comparison_group("scope", "gpt-test-sol", "max", "worker-test-1", "Inspect this task", self.schema)
        for tier in ("priority", "default"):
            for index in range(5):
                self.history.record(group, f"{tier}-{index}", {"tier": tier, "input_tokens": 8192,
                    "output_tokens": 256, "cached_input_tokens": 0, "elapsed_seconds": 5})
        evidence = self.run_selection()
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(self.calls[0]["service_tier"], "default")
        self.assertEqual(self.calls[0]["reasoning"], "max")
        self.assertEqual(evidence["fast_benefit"]["reason"], "observed_fast_gain_below_threshold")

    def test_resume_does_not_guess_replayed_context_size(self):
        self.run_selection(resume_session_id="existing-thread")
        self.assertEqual(self.calls[-1]["service_tier"], "priority")

    def test_material_reading_plan_is_standard_without_extra_calls_or_sticky_tier(self):
        evidence = self.run_selection(key="planner-1", planning_materials={"standard_planning": True})
        self.assertEqual(len(self.calls), 1)
        self.assertEqual(self.calls[-1]["service_tier"], "default")
        self.assertEqual(evidence["fast_benefit"]["reason"], "material_reading_plan")
        self.run_selection(key="worker-test-1")
        self.assertEqual(self.calls[-1]["service_tier"], "priority")

    def test_material_rule_preserves_explicit_profiles_and_works_without_benefit_learning(self):
        for profile in ("all-fast", "follow-entry"):
            self.run_selection(speed_profile_name=profile, planning_materials={"standard_planning": True})
            self.assertEqual(self.calls[-1]["service_tier"], "priority")
        self.runner.benefit_history = None
        evidence = self.run_selection(planning_materials={"standard_planning": True})
        self.assertEqual(self.calls[-1]["service_tier"], "default")
        self.assertEqual(evidence["fast_benefit"]["reason"], "material_reading_plan")

    def test_execution_still_respects_waiting_value_after_material_planning(self):
        self.run_selection(planning_materials={"standard_planning": True})
        evidence = self.run_selection(wait_value="background")
        self.assertEqual(self.calls[-1]["service_tier"], "default")
        self.assertEqual(evidence["fast_benefit"]["reason"], "background_wait_value")

    def test_history_failure_keeps_original_tier_and_completed_result(self):
        self.history.path.write_text("{bad", encoding="utf-8")
        evidence = self.run_selection()
        self.assertEqual(self.calls[-1]["service_tier"], "priority")
        self.assertEqual(evidence["fast_benefit"]["reason"], "history_unavailable")

    def test_standard_is_never_upgraded(self):
        self.run_selection(service_tier="default")
        self.assertEqual(self.calls[-1]["service_tier"], "default")

    def test_accepted_measurement_is_recorded_once_and_failed_calls_are_ignored(self):
        evidence = self.run_selection()
        path = self.base / "invocation.json"
        evidence.update({
            "requested_model": "gpt-test-sol", "observed_models": ["gpt-test-sol"],
            "requested_reasoning": "max", "observed_reasoning": ["max"],
            "inference_timing": {"tier": "priority", "input_tokens": 8192,
                "output_tokens": 256, "cached_input_tokens": 0, "elapsed_seconds": 5},
        })
        atomic_write_json(path, evidence)
        outcome = RunOutcome(0, False, False, False, "", {}, "", path, "session", True, True)
        self.runner.record_benefit(outcome)
        self.runner.record_benefit(outcome)
        self.assertEqual(len(load_json(self.history.path)["samples"]), 1)
        outcome.returncode = 1
        self.runner.record_benefit(outcome)
        self.assertEqual(len(load_json(self.history.path)["samples"]), 1)

    def test_runtime_scope_is_refreshed_before_each_invocation(self):
        with patch.object(self.runner, "benefit_scope", side_effect=["provider-one", "provider-two"]):
            first = self.run_selection()["fast_benefit"]["comparison_group"]
            second = self.run_selection()["fast_benefit"]["comparison_group"]
        self.assertNotEqual(first, second)

    def test_waiting_rule_still_applies_when_benefit_history_is_disabled(self):
        self.runner.benefit_history = None
        evidence = self.run_selection(wait_value="background")
        self.assertEqual(self.calls[-1]["service_tier"], "default")
        self.assertEqual(evidence["fast_benefit"]["reason"], "background_wait_value")
