# Upstream attribution

Codex FastPilot is derived from [wei-er582/codex-auto-orchestrator](https://github.com/wei-er582/codex-auto-orchestrator).
Baseline commit: `b3b789d0a05a8c295da32c27c43893fbcd731b87`.
The original MIT license and copyright remain in [LICENSE](LICENSE).
The original release/development records in `docs/releases/` and `docs/development/` retain their historical names and dates.

The derived version adds waiting-value routing, conservative observed-benefit downgrades,
and Standard planning only when the planner reads enough user input materials.
This release renames the plugin, skill, CLI, Python package, schemas, state directories,
environment variables, and distribution package to FastPilot.
