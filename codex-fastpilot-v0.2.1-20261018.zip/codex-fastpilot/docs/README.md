---
status: active
owner: daidai1215
last_verified: 2026-10-18
verified_commit: "codex-fastpilot@v0.2.1"
applies_to: [codex-fastpilot]
supersedes: []
---

# Documentation

- [Functions](product/FUNCTIONS.md)
- [Architecture](architecture/OVERVIEW.md)
- [Initial architecture decision](architecture/adr/0001-plugin-skill-python-fastpilot.md)
- [Speed policy before planning](architecture/adr/0003-speed-policy-before-planning.md)
- [Temporary controllers and durable controls](architecture/adr/0004-temporary-controller-and-durable-controls.md)
- [Configuration](reference/CONFIGURATION.md)
- [Development](runbooks/DEVELOPMENT.md)
- [Testing](runbooks/TESTING.md)
- [Deployment](runbooks/DEPLOYMENT.md)
- [Rollback](runbooks/ROLLBACK.md)
- [Development log](development/2026.md)
- [Releases](releases/README.md)
