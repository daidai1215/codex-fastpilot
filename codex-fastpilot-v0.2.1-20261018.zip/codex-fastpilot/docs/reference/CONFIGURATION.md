---
status: active
owner: daidai1215
last_verified: 2026-10-18
verified_commit: "codex-fastpilot@v0.2.1"
applies_to: [codex-fastpilot]
supersedes: []
---

# Configuration

## Runtime settings

| Setting | Default | Purpose |
| --- | --- | --- |
| `--policy` | `balanced` | `economy`, `balanced`, or `quality` retry and concurrency policy |
| `--run-root` | `%USERPROFILE%\.codex\fastpilot\runs` | Durable state and evidence outside target repositories |
| `--config` | `%USERPROFILE%\.codex\fastpilot\config.json` | Named speed profiles and explicit prompt policy |
| `--speed-profile` | saved default | Select another profile for a new job |
| `--wait-value` | `blocking` | User waiting priority: `blocking` or unattended `background` |
| `--no-adaptive-fast` | off | Disable benefit-based tier adjustments; waiting-value filtering remains active |
| `--custom-speed` | off | Open per-job speed selection before planning |
| `--codex-command` | short npm Codex path on Windows, otherwise `codex` | Test or alternate CLI executable |
| `CODEX_FASTPILOT_CODEX_COMMAND` | unset | Environment-level Codex override |
| `CODEX_FASTPILOT_READ_ISOLATION` | `snapshot` on Windows, `native` elsewhere | Executable read-task isolation |
| `CODEX_FASTPILOT_PAUSE_IDLE_SECONDS` | `1800` | Controller exit delay while paused |
| `CODEX_FASTPILOT_WORKER` | managed internally | Recursive-orchestration guard |

Balanced mode permits three ordinary workers, one implementation/reasoning retry per step, and one exclusive Ultra per job. Environment, permission, timeout, cancellation, and external uncertainty do not escalate reasoning.

## Speed configuration

The profile file has `version: 1`, `prompt_policy: explicit`, one saved default name, and any number of named profiles. Each profile records:

- a complete `sol` and `terra` matrix;
- `default` or `priority` for every currently supported reasoning effort;
- known model-version/effort combinations;
- the catalog fingerprint and timestamps.

Built-in templates cannot be overwritten or deleted:

| Template | Behavior |
| --- | --- |
| `balanced` | Fast for Sol Max, Sol Ultra, and Terra Ultra only |
| `all-fast` | Fast for every supported cell |
| `all-standard` | Standard for every cell |
| `follow-entry` | Use the entry thread's Service Tier for all supported cells when the surface exposes it; otherwise record `default-unavailable` and use Standard |

First setup must save a named user profile and make it default. A model-version or reasoning change is detected by combination identity, not just by the family name. New cells default to Standard in the form and require explicit confirmation before planning.

The one-shot page validates loopback Host, loopback Origin, random URL token, random CSRF value, maximum request size, and the dynamic matrix schema. It shows entry settings only as context and never displays the task body.

## Job snapshot and evidence

`speed-policy.json` is immutable until an explicit runtime speed control. Every revision stores the selected profile, complete matrix, model bindings, catalog fingerprint, source, and revision number. A global profile edit cannot drift into an active job.

Every subprocess explicitly receives:

```text
model
model_reasoning_effort
service_tier
```

`priority` is Fast and `default` is Standard. A Fast rejection is retried once as Standard. A successful read-only Fast call observed as Standard is also retried once explicitly as Standard; write calls already completed at Standard are not duplicated and are reported as degraded.

## Authentication and platform details

The runtime inherits the authenticated Codex session. If `codex login status` confirms ChatGPT login, child processes remove an inherited `CODEX_API_KEY` so it cannot silently override that login. API-key-only installations keep the variable.

On Windows the runtime prefers `%APPDATA%\npm\codex.cmd` when available. This avoids longer WinGet helper paths. Snapshot isolation uses a detached worktree for clean Git or a private copy for dirty/non-Git workspaces, then verifies a complete content digest before cleanup.

## Waiting value

The saved matrix remains the eligibility policy. For ordinary named profiles and `balanced`, a Fast cell uses Standard when the job or individual task has background waiting value. A blocking call may retain Fast subject to observed benefit. Standard cells never become Fast. Explicit `all-fast` and `follow-entry` profiles keep their exact tier, including on background jobs.

The entry agent passes `--wait-value background` only for explicitly unattended, overnight or non-blocking work. A temporary background controller does not by itself imply low waiting value. A task may add optional `wait_value: "blocking" | "background"`; omission inherits the job. A background job cannot be promoted by a planner's task hint. The value is stored in controller state and inherited by resumed jobs and linked follow-ups. No separate classification call is made.

## Material-aware planning

`--materials-file` supplies local attachment metadata to `start`, `run`, `steer`, or `followup`. It is copied into durable job/control state before the command returns. Example:

```json
{"planning_reads_materials": true, "attachments": [{"path": "C:/input/report.pdf", "mime_type": "application/pdf"}]}
```

Paths may be absolute or relative to the target workspace. Missing MIME types are inferred from extensions; unknown types count as non-image files. Duplicate resolved paths count once. Attachment contents are not read to choose a tier. The metadata grants no additional filesystem or external-write authority; the existing sandbox and isolation rules still apply. The entry agent must provide accessible local paths and preserve material references in the task.

Only a planner that needs to read the input materials uses this override, and only for more than five images (six or more) or at least one non-image file. With five or fewer images, no materials, or `planning_reads_materials=false`, the original rules apply. Only actual user input materials count, not task staging files or ordinary workspace files. An omitted declaration defaults to false.

The override applies before each attempt of the existing planner. It never adds a classification/planning model call or changes an in-flight call. Workers and reviews resume the original matrix, waiting value and observed benefit after planning; they are not forced to Fast. Explicit `all-fast` and `follow-entry` keep precedence. `--no-adaptive-fast` disables benefit learning only, not this rule. Evidence records `material_reading_plan` and the material summary.

A replacement objective uses that steering request's metadata; omission clears the previous attachment condition. Resuming the same plan retains its stored metadata, while a new linked follow-up job starts without prior attachments unless supplied again. No global Codex tier or desktop entry-turn setting is changed.

## Observed Fast benefit

The optional adjustment runs before each invocation. It uses only already completed, engine-accepted calls and never runs duplicate tasks, paid probes or A/B benchmarks. `--no-adaptive-fast` disables it for a new job.

Eligible measurements require one complete CLI `turn.started` / `turn.completed` pair, a confirmed returned service tier, known input/output/cache token counts, at least 32 output tokens and at least 0.5 seconds of elapsed time. Any tool item, resumed invocation, multiple turns, missing tier, unsuccessful result, timeout, cancellation or interruption excludes the measurement. The elapsed interval is client-observed turn latency, not server GPU time.

Comparison groups separate the runtime/provider/configuration generation, credential generation, model, reasoning effort, role, prompt-size range and output schema. Within a group, observations must also match bounded input/output token-volume ranges and cold/partial/warm cache classes. Only numeric timing/usage statistics and hashed group/identity keys are saved in the history; prompts, responses and credentials are not copied into it. Existing invocation logs retain their upstream behavior.

Every observed volume/cache bucket needs at least five Fast and five Standard samples. A downgrade requires the Fast upper-quartile throughput to be no more than 1.10 times the Standard lower-quartile throughput in every bucket. Strong or noisy Fast results, incomplete controls or unknown evidence retain the original tier. These are conservative observational comparisons, not randomized causal estimates. Different task contents and changing backend conditions can still affect latency.

History is stored at `<run-root>/.fast-benefit-history.json`, with a maximum of 1,000 accepted samples and a seven-day eligibility window. Expired samples no longer drive a downgrade; normal matrix choices can resume, without sending test calls. Provider/configuration/auth-file generation and relevant API-key environment changes separate comparisons. An authentication refresh can conservatively start a fresh group. History errors leave the original profile choice in place.

With only one tier's history, the filter cannot infer the counterfactual speed of the other tier and makes no benefit-based change. It relies on comparable Fast/Standard observations that arise from normal use. Returned tiers are evidence about serving; the throughput ratio is not an account billing multiplier or a promised savings percentage.

Invocation evidence records `fast_benefit`, the client timing candidate (if eligible), and whether an accepted sample was saved. Reports show profile tier, waiting value and selection reason. A job speed-policy snapshot is not rewritten by observations; the effective invocation tier is recorded separately.
