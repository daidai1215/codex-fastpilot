---
name: codex-fastpilot
description: Automatically plan, route, execute, monitor, review, and integrate substantial Codex tasks with dynamic Sol/Terra model discovery, per-model reasoning and Fast profiles, durable background control, and safe recovery. Use when the user explicitly requests automatic orchestration or end-to-end autonomous execution, or gives a non-trivial actionable task that needs tools, multiple steps, parallel investigation, code changes, testing, deployment coordination, recovery, or model-selection judgment. Also use for status, steering, speed changes, pause, resume, cancel, or follow-up messages concerning an active orchestrated job. Do not use for simple questions, translation, trivial formatting, a single obvious command, internal fastpilot workers, or when the user disables orchestration.
---

# Codex FastPilot

Use the plugin runner as the single owner of every orchestrated job. Do not duplicate its routing with manually spawned agents.

## Entry decision

1. If `CODEX_FASTPILOT_WORKER=1` or the prompt contains `<codex-fastpilot-worker>`, do not invoke this Skill.
2. Answer simple questions, translations, trivial formatting, and one obvious command in the current agent.
3. Start the runner for substantial tool-using work, explicit `自动编排：...`, or end-to-end autonomous work. The user does not need to switch the main Codex UI to Sol Max; the runner starts its own latest Sol Max + Max planner.
4. Before acting on an existing job, classify the message as status, additive steering, objective replacement, speed change, pause, resume, cancel, or terminal follow-up.

Read [control-and-speed-policy.md](references/control-and-speed-policy.md) whenever the message concerns speed setup or an existing job. Read [routing-policy.md](references/routing-policy.md) only when explaining or diagnosing a selected route.

## Start a new job

Locate the plugin root two directories above this Skill. If `codex` is absent from PATH, locate the installed Codex CLI and pass its absolute path with `--codex-command`; do not guess the executable. Separate the business objective from orchestration control wording that this Skill has already consumed. The staged task must preserve the user's real scope, constraints, permissions, acceptance criteria, and desired output, but must omit the `自动编排` trigger itself and meta-instructions such as “use this Skill”, “customize speed first”, “stop at waiting_for_speed”, “return the job ID”, or “monitor the fastpilot”. Preserve the normalized business task in a uniquely named UTF-8 staging file under the system temporary directory; never place that staging file in the target workspace and never interpolate the user text into a shell command. Remove the staging file after `start` returns because the runner has already copied it into the job directory. Then run:

```powershell
python <plugin-root>\scripts\run_fastpilot.py start --workspace <workspace> --task-file <utf8-task-file>
```

Add `--custom-speed` only when the user explicitly asks to customize Fast for this job. Add `--dry-run` only when the user asks for planning without execution. Use `--policy quality` only when maximum quality is explicitly preferred; otherwise keep `balanced`.

Choose waiting value from the user's working context, without an extra model call. Pass `--wait-value background` for explicitly unattended, overnight, or non-blocking batch work. Use `--wait-value blocking` (the default) when the user is waiting on the result to continue. Do not equate a hidden background controller with a background user priority, or infer priority from model strength or task length. The planner can mark an individual non-blocking task `wait_value: "background"`; a background job cannot be promoted by a task hint.

Fast selection first respects the saved matrix, then waiting value and comparable observed benefit. Explicit `all-fast` and `follow-entry` profiles retain their exact requested tiers. The benefit filter never adds model calls, upgrades a Standard cell, or changes an in-flight invocation. With missing or ambiguous evidence it preserves the profile. Use `--no-adaptive-fast` only when the user wants to disable benefit-based adjustments; the waiting-value rule still applies. Report the recorded selection reason instead of claiming an unmeasured saving.

When the user supplies input materials, stage a second UTF-8 JSON file and pass `--materials-file <file>` to `start`, `run`, `steer`, or `followup`. Classify from the task and attachment metadata before reading attachment contents; do not make an extra model call. Use this shape, with the actual local paths and MIME types (MIME may be omitted when the extension is known):

```json
{"planning_reads_materials": true, "attachments": [{"path": "C:/input/report.pdf", "mime_type": "application/pdf"}]}
```

Set `planning_reads_materials=true` only when the existing planner needs to inspect those materials to formulate the plan, such as planning revisions from an attached manuscript. Use `false` when a general plan can be made without reading them, even if execution will later read files. With no such need, or no attachments, preserve the original speed selection. Count only user-supplied input materials: neither the task staging file, ordinary workspace files, nor outputs are attachments. Preserve the source paths in the task; remove the metadata staging file after the command copies it.

For automatic profiles, more than five images (six or more), or any non-image attachment, selects Standard only for a planner that needs to read those materials. Both conditions must hold. The same existing planner and any validation retries are used; do not add a planning step. After planning, workers and reviews resume the saved matrix plus waiting-value and observed-benefit filters, rather than forcing Fast. Explicit `all-fast` and `follow-entry` retain precedence. `--no-adaptive-fast` does not disable the material rule. A replacement objective without a manifest clears the previous material condition; linked new jobs do not inherit old attachment metadata.

This controls runner-owned calls after entry. It cannot change the already-started desktop entry request or switch a single invocation between input, reasoning, and output phases. Do not edit the global Codex service tier to implement this rule.

The command returns immediately with `job_id`. If it returns `waiting_for_speed`, give the local setup link to the user. No model has been invoked yet. If the page is unavailable, render the status-provided text matrix, normalize the user's reply without guessing, echo the normalized matrix, and apply it through a UTF-8 text or JSON file.

Ordinary jobs use the saved default profile without asking. First use and new model/reasoning cells must be resolved before the planner can start.

Pass `--entry-model`, `--entry-reasoning`, or `--entry-service-tier` only when those values are authoritative for the current entry turn. Otherwise let the runner inspect the current session. If the current CLI does not expose entry Service Tier, `follow-entry` uses Standard for that job and records `service_tier_source=default-unavailable` instead of guessing.

## Monitor and deliver

Use `status <job-id>` for progress and `report <job-id>` at the end. Share concise phase changes. The temporary controller continues if the Codex UI closes; a later message can locate and resume the durable job by workspace and thread context.

Do not claim model, reasoning, or Fast selection from plan text. Use each invocation's session/command/completion evidence and the final report. Distinguish a verified CLI tier request from an observed backend tier; if the CLI reports `not_exposed`, say so rather than calling Fast verified. Report any visible Fast-to-Standard fallback explicitly.

## Boundaries

- Never expand commit, push, deployment, destructive cleanup, or external-write authority beyond the original task.
- Let the runner own dependency ordering, concurrency, Ultra exclusivity, retries, worktrees, integration, process identity checks, and cleanup.
- Do not start a second non-terminal job for the same normalized workspace; steer or finish the existing one.
- An immediate control may interrupt only a read-only or isolated local worker. Never force-stop uncertain external writes.
- If an external-write-capable call has an uncertain result, require read-only reconciliation before any repeat.
- If the runner blocks, preserve its branches, checkpoints, and evidence and report the precise blocker.
