from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from fastpilot.materials import load_materials, normalize_materials, planning_material_summary


class MaterialPolicyTests(unittest.TestCase):
    def summary(self, count=0, *, reads=True, other=False):
        attachments = [{"path": f"image-{i}.png"} for i in range(count)]
        if other:
            attachments.append({"path": "report.pdf"})
        return planning_material_summary(normalize_materials({
            "planning_reads_materials": reads, "attachments": attachments,
        }, ROOT))

    def test_image_threshold_and_document_condition(self):
        self.assertFalse(self.summary(5)["standard_planning"])
        self.assertTrue(self.summary(6)["standard_planning"])
        self.assertTrue(self.summary(other=True)["standard_planning"])
        self.assertFalse(self.summary()["standard_planning"])

    def test_no_reading_preserves_original_policy_even_with_large_inputs(self):
        self.assertFalse(self.summary(20, reads=False, other=True)["standard_planning"])

    def test_normalization_uses_metadata_without_reading_materials(self):
        with patch.object(Path, "read_text", side_effect=AssertionError("material content read too early")):
            result = normalize_materials({"planning_reads_materials": True, "attachments": [
                {"path": "unusual.asset", "mime_type": "IMAGE/PNG; charset=binary"},
                {"path": "./unusual.asset", "mime_type": "image/png"},
            ]}, ROOT)
        self.assertEqual(len(result["attachments"]), 1)
        self.assertEqual(planning_material_summary(result)["image_count"], 1)
        self.assertTrue(Path(result["attachments"][0]["path"]).is_absolute())

    def test_unknown_file_type_is_non_image(self):
        result = normalize_materials({"planning_reads_materials": True,
            "attachments": [{"path": "source.unknown-extension"}]}, ROOT)
        self.assertTrue(planning_material_summary(result)["standard_planning"])

    def test_invalid_manifest_does_not_silently_change_tier(self):
        for raw in (["file.pdf"], {"planning_reads_materials": "false"},
                    {"attachments": ["file.pdf"]}, {"attachments": [{"path": ""}]},
                    {"attachments": [{"path": "a.png", "mime_type": 1}]}, {"image_count": 6}):
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                normalize_materials(raw, ROOT)

    def test_bom_manifest_and_absent_manifest(self):
        with tempfile.TemporaryDirectory() as directory:
            workspace = Path(directory)
            manifest = workspace / "材料清单.json"
            manifest.write_text(json.dumps({"planning_reads_materials": True,
                "attachments": [{"path": "报告.pdf"}]}, ensure_ascii=False), encoding="utf-8-sig")
            self.assertTrue(planning_material_summary(load_materials(manifest, workspace))["standard_planning"])
            self.assertFalse(planning_material_summary(load_materials(None, workspace))["standard_planning"])
